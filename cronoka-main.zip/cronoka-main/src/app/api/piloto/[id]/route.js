import { NextResponse } from "next/server";
import { conectDB } from "../../../../lib/mongodb";
import Piloto from "../../../model/piloto";

export async function PUT(request, { params }) {
  try {
    await conectDB();

    const { id } = await params; // pega o ID da URL
    const dados = await request.json();

    const Atualizada = await Piloto.findByIdAndUpdate(id, dados, { new: true });

    if (!Atualizada) {
      return NextResponse.json({ error: "Piloto não encontrada" }, { status: 404 });
    }

    return NextResponse.json({ data: Atualizada }, { status: 200 });

  } catch (err) {
    console.error("Erro ao atualizar piloto:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
export async function GET(request, { params }) {
  try {
    await conectDB();
    const { id } = await params;
    const PilotoEncontrada = await Piloto.findById(id).populate('categorias');

    if (!PilotoEncontrada) {
      return NextResponse.json({ error: "Piloto não encontrada" }, { status: 404 });
    }
    return NextResponse.json({ data: PilotoEncontrada }, { status: 200 });
  } catch (err) {
    console.error("Erro ao buscar piloto:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    await conectDB();
    const { id } = params;

    const Removida = await Piloto.findByIdAndDelete(id);
    if (!Removida) {
      return NextResponse.json({ error: "Piloto não encontrada" }, { status: 404 });
    }

    return NextResponse.json({ message: "Piloto removida com sucesso" }, { status: 200 });
  } catch (err) {
    console.error("Erro ao excluir piloto:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
